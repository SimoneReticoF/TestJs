// esercizio 1
function calcolaGiorni(data1, data2) {
    if (data2 < data1) {
      throw new Error("La seconda data è precedente alla prima data.");
    }
  
    var unGiorno = 24 * 60 * 60 * 1000; // Rappresenta un giorno in millisecondi
    var differenzaGiorni = Math.floor((data2 - data1) / unGiorno);
    return differenzaGiorni;
  }
  
  // Esempi di chiamate alla funzione
  var primaData = new Date('2023-01-01');
  var secondaData = new Date('2023-01-10');
  var risultato = calcolaGiorni(primaData, secondaData);
  console.log(risultato);
  
  var data1 = new Date('2023-02-01');
  var data2 = new Date('2023-01-01');
  try {
    var risultatoErrato = calcolaGiorni(data1, data2);
    console.log(risultatoErrato);
  } catch (errore) {
    console.log(errore.message);
  }

  
  // esercizio 2

  function confrontaOggetti(o1, o2) {
    var keys1 = Object.keys(o1);
    var keys2 = Object.keys(o2);
  
    if (keys1.length !== keys2.length) {
      return false;
    }
  
    for (var i = 0; i < keys1.length; i++) {
      var key = keys1[i];
      if (!o2.hasOwnProperty(key) || o1[key] !== o2[key]) {
        return false;
      }
    }
  
    return true;
  }
  
  // Esempi di chiamate alla funzione
  var o1 = { nome: "Mario", cognome: "Rossi" };
  var o2 = { nome: "Mario", cognome: "Rossi" };
  var confronto1 = confrontaOggetti(o1, o2);
  console.log(confronto1);
  
  var o3 = { nome: "Mario", cognome: "Rossi" };
  var o4 = { x: 10, y: 20 };
  var confronto2 = confrontaOggetti(o3, o4);
  console.log(confronto2);
  

  // esercizio 3
  function mappaNumeri(array, funzione) {
    var nuovoArray = array.map(funzione);
    console.log(nuovoArray.join(' '));
  }
  
  // Funzione per raddoppiare i numeri
  function raddoppia(numero) {
    return numero * 2;
  }
  
  // Funzione per aumentare i numeri di 10
  function aumentaDi10(numero) {
    return numero + 10;
  }
  
  // Esempi di chiamate alla funzione mappaNumeri
  var array1 = [10, 20, 30];
  mappaNumeri(array1, raddoppia);
  
  var array2 = [10, 20, 30];
  mappaNumeri(array2, aumentaDi10);