// Esercizio 1 
function filterPeopleByAge(people) {
  var filteredPeople = [];
  
  for (var i = 0; i < people.length; i++) {
    if (people[i].età > 30) {
      filteredPeople.push(people[i]);
    }
  }
  
  return filteredPeople;
}

// Esempio di array di persone
var persone = [
  { nome: 'Mario', cognome: 'Rossi', età: 25 },
  { nome: 'Giulia', cognome: 'Verdi', età: 40 },
  { nome: 'Luca', cognome: 'Bianchi', età: 35 },
  { nome: 'Anna', cognome: 'Gialli', età: 28 },
  { nome: 'Roberto', cognome: 'Neri', età: 45 },
  { nome: 'Laura', cognome: 'Marroni', età: 50 }
];

// Chiamata alla funzione per filtrare le persone con un'età superiore a 30
var personeFiltrate = filterPeopleByAge(persone);

// Stampa le informazioni delle persone filtrate
for (var i = 0; i < personeFiltrate.length; i++) {
  var persona = personeFiltrate[i];
  console.log('Nome:', persona.nome, 'Cognome:', persona.cognome, 'Età:', persona.età);

}


// Esercizio 2

function moltiplicaArray(array, fattore) {
  var nuovoArray = array.map(function(numero) {
    return numero * fattore;
  });
  
  return nuovoArray;
}

// Esempi di chiamate alla funzione
var array1 = [1, 2, 3, 4, 5];
var fattore1 = 2;
var risultato1 = moltiplicaArray(array1, fattore1);
console.log(risultato1);

var array2 = [10, 20, 30, 40, 50];
var fattore2 = 3;
var risultato2 = moltiplicaArray(array2, fattore2);
console.log(risultato2);

var array3 = [-1, -2, -3, -4, -5];
var fattore3 = -2;
var risultato3 = moltiplicaArray(array3, fattore3);
console.log(risultato3);

// esercizio 3 

function unisciSet(set1, set2) {
  var differenza = new Set([...set1].filter(x => !set2.has(x)));
  return differenza;
}

// Esempi di chiamate alla funzione
var set1 = new Set([1, 2, 3, 4, 5]);
var set2 = new Set([4, 5, 6, 7, 8]);
var risultato = unisciSet(set1, set2);
console.log(risultato);

// esercizio 4

function salutaPersona(persona) {
  if (!persona.hasOwnProperty('rate')) {
    console.log("nessun rate");
  } else {
    var rate = persona.rate;
    if (rate >= 0 && rate <= 10) {
      console.log("rate basso");
    } else if (rate >= 11 && rate <= 50) {
      console.log("rate medio");
    } else if (rate >= 51 && rate <= 100) {
      console.log("rate alto");
    }
  }
}

// Esempi di chiamate alla funzione
var persona1 = { nome: "Mario", cognome: "Rossi", rate: 8 };
salutaPersona(persona1);

var persona2 = { nome: "Giulia", cognome: "Verdi" };
salutaPersona(persona2);

var persona3 = { nome: "Luca", cognome: "Bianchi", rate: 75 };
salutaPersona(persona3);